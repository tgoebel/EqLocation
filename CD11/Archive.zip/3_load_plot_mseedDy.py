#!/usr/bin/python3
"""
    - run 2_cd11_2_mseedDy.py first
    - this script loads resulting output and creates basci plots
"""
#=================================================================================
#                       modules
#=================================================================================
import matplotlib as mpl
#mpl.use('Agg')
import matplotlib.pyplot as plt

import numpy as np
from obspy.core import read
from obspy.core import UTCDateTime

#=================================================================================
#                       files and parameters
#=================================================================================
mseed_dir= '/media/tgoebel/Data/seis/BlueMountain/mseed'
l_Sta    = ['BM01', 'BM02', 'BM03', 'BM04', 'BM06', 'BM07', 'BM09', 'BM10']
l_Sta    = ['BM03']# 'BM02',
# bandpass filter
f_min, f_max = .5, 50
#tmin     = UTCDateTime('2019-05-02')
tmin     = UTCDateTime('2019-06-25')
tmax     = UTCDateTime('2019-06-26')

for sta in l_Sta:
    print(  '--------------------- station', sta, '----------------------------')
    curr_t    = tmin
    n_noReads = 0
    #===============================2=================================================
    #                      load mseed files
    #=================================================================================
    while (tmax-curr_t) > 0:
        t_str = '%04d%02d%02d'%(curr_t.year,curr_t.month,curr_t.day)
        #write to mseed
        mseed_file = '%s_%s.mseed'%( sta, t_str)
        SEIS = read( '%s/%s/%s'%( mseed_dir, sta, mseed_file))
        ###B### detrend and filtering, bandpass
        SEIS.detrend( type = 'linear')# linear or simple or demean
        SEIS.filter( 'bandpass', freqmin=f_min, freqmax=f_max, corners = 2)
        print( SEIS[0].stats)
        SEIS[2].plot()
        curr_t += 3600*24

